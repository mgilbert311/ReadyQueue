#!/bin/sh

cp xinuSol /srv/tftp/xinu.boot
